#include <iostream>
#include <string>
using namespace std;

void AO() {
	cout << "=============================================================" << endl;
	cout << "                        Pesawat AO-103                       " << endl;
	cout << "=============================================================" << endl;
	cout << " Kelas Economy              : Rp 6.050.000  " << endl;
	cout << " Kelas Premium Economy      : Rp 14.002.500 " << endl;
	cout << " Kelas Business             : Rp 4.250.320  " << endl;
	cout << " Kelas First Class          : Rp 50.532.000 " << endl;
	cout << "=============================================================" << endl;
}

void GA() {
	cout << "=============================================================" << endl;
	cout << "                        Pesawat GA-402                       " << endl;
	cout << "=============================================================" << endl;
	cout << " Kelas Economy              : Rp 5.930.500  " << endl;
	cout << " Kelas Premium Economy      : Rp 13.753.400 " << endl;
	cout << " Kelas Business             : Rp 4.060.320  " << endl;
	cout << " Kelas First Class          : Rp 40.982.000 " << endl;
	cout << "=============================================================" << endl;
}

void UA() {
	cout << "=============================================================" << endl;
	cout << "                        Pesawat UA-110                       " << endl;
	cout << "=============================================================" << endl;
	cout << " Kelas Economy              : Rp 7.000.500  " << endl;
	cout << " Kelas Premium Economy      : Rp 15.003.600 " << endl;
	cout << " Kelas Business             : Rp 6.080.000  " << endl;
	cout << " Kelas First Class          : Rp 60.002.000 " << endl;
	cout << "=============================================================" << endl;
}

void MH() {
	cout << "=============================================================" << endl;
	cout << "                        Pesawat MH-739                       " << endl;
	cout << "=============================================================" << endl;
	cout << " Kelas Economy              : Rp 5.630.500  " << endl;
	cout << " Kelas Premium Economy      : Rp 14.903.600 " << endl;
	cout << " Kelas Business             : Rp 5.089.000  " << endl;
	cout << " Kelas First Class          : Rp 50.072.000 " << endl;
	cout << "=============================================================" << endl;
}

void ar() {
	string al[4] = {"AO-103", "GA-402", "UA-110", "MH-739"};
	int hr[4] = {6050000, 5930500, 7000500, 5630500};
	for (int i = 0; i < 3; i++) {
		for (int j = i + 1; j < 4; j++) {
			if (hr[i] > hr[j]) {
				int tr = hr[i];
				hr[i] = hr[j];
				hr[j] = tr;
				string ta = al[i];
				al[i] = al[j];
				al[j] = ta;
			}
		}
	}
	for (int i = 0; i < 4; i++) {
		cout << "Pesawat " << al[i] << endl;
		if (al[i] == "AO-103") {
			AO();
		} else if (al[i] == "GA-402") {
			GA();
		} else if (al[i] == "UA-110") {
			UA();
		} else if (al[i] == "MH-739") {
			MH();
		}
	}
}

void bc(int ac, int ps, int cc) {
	long p = 0;
	double d = 0.0;
	switch (ac) {
		case 1:
			if (cc == 1) p = 6050000;
			else if (cc == 2) p = 14002500;
			else if (cc == 3) p = 4250320;
			else if (cc == 4) p = 50532000;
			break;
		case 2:
			if (cc == 1) p = 5930500;
			else if (cc == 2) p = 13753400;
			else if (cc == 3) p = 4060320;
			else if (cc == 4) p = 40982000;
			break;
		case 3:
			if (cc == 1) p = 7000500;
			else if (cc == 2) p = 15003600;
			else if (cc == 3) p = 6080000;
			else if (cc == 4) p = 60002000;
			break;
		case 4:
			if (cc == 1) p = 5630500;
			else if (cc == 2) p = 14903600;
			else if (cc == 3) p = 5089000;
			else if (cc == 4) p = 50072000;
			break;
		default:
			cout << "Pilihan tidak valid!" << endl;
			return;
	}
	long tp = p * ps;
	if (tp > 40000000) {
		d = 0.15;
	} else if (tp > 10000000) {
		d = 0.10;
	} else if (tp > 4000000) {
		d = 0.05;
	}
	long dp = tp * (1 - d);
	cout << "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" << endl;
	cout << "Harga untuk kelas pilihan : Rp " << p << endl;
	cout << "Total untuk " << ps << " penumpang : Rp " << tp << endl;
	cout << "Diskon : " << (d * 100) << "%" << endl;
	cout << "Total setelah diskon : Rp " << dp << endl;
	cout << "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" << endl;
}

void pr() {
	int ps, ac, cc;
	cout << "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" << endl;
	cout << "Masukkan jumlah penumpang : "; cin >> ps;
	cout << "Pilih pesawat : " << endl;
	cout << "1. Pesawat AO-103" << endl;
	cout << "2. Pesawat GA-402" << endl;
	cout << "3. Pesawat UA-110" << endl;
	cout << "4. Pesawat MH-739" << endl;
	cout << "Masukkan pilihan (1-4) : "; cin >> ac;
	cout << "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" << endl;
	cout << endl;
	cout << "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" << endl;
	cout << "Pilih kelas : " << endl;
	cout << "1. Economy" << endl;
	cout << "2. Premium Economy" << endl;
	cout << "3. Business" << endl;
	cout << "4. First Class" << endl;
	cout << "Masukkan pilihan kelas (1-4): "; cin >> cc;
	cout << "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" << endl;
	cout << endl;
	bc(ac, ps, cc);
}

int main() {
	int pilih;
	do {
		cout << endl;
		cout << "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" << endl;
		cout << "                MASKAPI PENERBANGAN ALL WORLD                " << endl;
		cout << "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" << endl;
		cout << " Enjoy The Journey, Enjoy The traveler, Enjoy The experience " << endl;
		cout << endl;
		cout << " Silakan Pilih Menu " << endl;
		cout << " 1. Daftar Harga Tiket " << endl;
		cout << " 2. Pemesanan & Pembayaran Tiket " << endl;
		cout << " 3. Keluar " << endl;
		cout << endl;
		cout << " Masukan Pilihan : "; cin >> pilih;
		cout << endl;
		switch (pilih) {
			case 1:
				ar();
				break;
			case 2:
				pr();
				break;
			case 3:
				cout << "Terima kasih, sampai jumpa!" << endl;
				break;
			default:
				cout << "Pilihan tidak valid, silakan coba lagi." << endl;
		}
	} while (pilih != 3);
	cin.get();
}